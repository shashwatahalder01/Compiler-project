#include<stdio.h>

main(){

puts("hello world")

return 0;
}

