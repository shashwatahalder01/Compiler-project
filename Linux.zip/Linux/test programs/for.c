#include<stdio.h>
main(){
	int a,b,i;
	puts("enter a number: ");
	get(a);
	for(i=1;i<11;i=i+1){	
	b=a*i;
	put(a);
	puts("X");
	put(i);
	puts("=");
	put(b);
	puts("  ");
	}
return 0;
}
