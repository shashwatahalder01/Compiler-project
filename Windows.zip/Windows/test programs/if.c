#include<stdio.h>
main(){
	int a,c;
	puts("enter a number: ");
	get(a);
	c=a%2;
	if(c==0){
	puts("number is even");
	}	
	if(c!=0){
	puts("number is odd");
	}
return 0;
}
