#include<stdio.h>
int find_gcd(int x, int y){
if(x%y == 0){
	puts("The gcd is : ");
	put(y);
}
else{
return find_gcd(y,x%y);
}

}
main(){
int a,b,c;
puts("enter 1st number: ");
	get(a);
puts("enter 2nd number: ");
	get(b);
if(a<b){
c=a;
a=b;
b=c;
}
find_gcd(a,b);
return 0;
}

