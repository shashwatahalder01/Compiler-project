#include<stdio.h>
main(){
int a;
int s=0;
int i=1;
	puts("enter a number: ");
	get(a);
while(i<=a){
	s=s+i;	
	i=i+1;
}   
	puts("Sum is = ");
	put(s);
 return 0;
}

