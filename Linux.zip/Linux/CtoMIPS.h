#include <bits/stdc++.h>
#define DEBUG if(0)
using namespace std;
extern int yylineno;
enum DataType{dt_none,dt_int,dt_char,dt_string,dt_float,dt_bool,dt_func,dt_err};
// Nodes of the AST
class Node {
private:
	string type;			
	string value;			
	DataType data_type;		
public:
	int line_number;		

	Node *child1;
	Node *child2;
	Node *child3;
	Node *child4;

	Node (string t, string v, Node *c1, Node *c2, Node *c3) {
		type = t;
		value = v;
		data_type = dt_none;
		child3 = c3;
		child2 = c2;
		child1 = c1;
		child4 = NULL;
		line_number = yylineno;
	}

	void addChild4(Node *c4){
		child4 = c4;
	}

	string getValue(){
		return value;
	}

	string getType(){
		return type;
	}

	DataType getDataType(){
		return data_type;
	}

	void setDataType(DataType dt){
		data_type = dt;
	}	
};
// Parameter of a function
class Parameter
{
private:
	string name;		
	DataType data_type;	
public:
	Parameter(){}
	Parameter(string id, DataType dt)
	:name(id), data_type(dt)
	{}

	DataType getDataType(){
		return data_type;
	}

	string getValue(){
		return name;
	}
};
// Class for the Meta data of the symbol table
class SymbolTableAux
{
private:
	DataType data_type;		
	DataType return_type;
	vector <Parameter> parameter_list;
	int parameter_count;
public:
	SymbolTableAux(){

	}

	SymbolTableAux(DataType dt)
	:data_type(dt) {
	}
	SymbolTableAux(DataType dt, DataType rtd, vector <Parameter> params)
	:data_type(dt), return_type(rtd), parameter_list(params), parameter_count(params.size()) {

	}
	DataType getDataType(){
		return data_type;
	}
	DataType getReturnDataType(){
		return return_type;
	}
	vector<Parameter> getParameterList(){
		return parameter_list;
	}
	int getParameterCount(){
		return parameter_count;
	}

};


class SymbolTable
{
private:
	int scope;				
	vector < map < string, SymbolTableAux > > symbols, backup_symbols;	
	string TYPE2STRING[8] = {"none", "int", "char", "string", "float", "bool", "func", "err"};
public:
	SymbolTable(){
		scope = 0;	
		symbols.push_back(map<string, SymbolTableAux>());	
	}
	bool findInCurrentScope(string id){
		if(symbols[scope].find(id) !=  symbols[scope].end()){
			return true;
		} else {
			return false;
		}
	}
	bool find(string id){
		for (int i = scope; i >= 0; i--)
		{
			if(symbols[i].find(id) !=  symbols[i].end()){
				return true;
			}
		}
		return false;
	}
	void addVariableInCurrentScope(string id, DataType dt){
		symbols[scope][id] = SymbolTableAux(dt);
	}

	SymbolTableAux* addFunction(string id, DataType rdt, vector<Parameter> params){
		symbols[0][id] = SymbolTableAux(dt_func, rdt, params);
		return &symbols[0][id];
	}
	void addScope(){
		scope++;
		map<string, SymbolTableAux> newMap;
		newMap.clear();
		symbols.push_back(newMap);
	}
	void removeScope(){
		if(scope == 0)	return ;
		scope--;
		symbols.pop_back();
	}
	DataType getDataType(string id){
		for (int i = scope; i >= 0; i--)
		{
			if(symbols[i].find(id) !=  symbols[i].end()){
				return (symbols[i].find(id))->second.getDataType();
			}
		}
		return dt_none;
	}

	DataType getFunctionDataType(string id){
		for (int i = scope; i >= 0; i--)
		{
			if(symbols[i].find(id) !=  symbols[i].end()){
				return (symbols[i].find(id))->second.getReturnDataType();
			}
		}
		return dt_none;
	}
	bool checkFunctionArgs(string id, vector<DataType> args_list) {
		for (int i = scope; i >= 0; i--)
		{
			if(symbols[i].find(id) !=  symbols[i].end()){
				SymbolTableAux temp = symbols[i].find(id)->second;
				if(temp.getDataType() != dt_func){continue;}
				if(temp.getParameterCount() != args_list.size()){continue;}
				bool flag = true;
				int x = 0;
				for(vector <Parameter>::iterator i = temp.getParameterList().begin(); i != temp.getParameterList().end() && x < args_list.size(); i++, x++){
					if (i->getDataType() != args_list[x]){
						flag = false;
						break;
					}
				}
				if(flag){
					return true;
				}
			}
		}
		return false;
	}
	vector<string> getFunctionParameters(string id){
		for (int i = scope; i >= 0; i--)
		{
			if(symbols[i].find(id) !=  symbols[i].end()){
				vector<Parameter> param_list =  symbols[i].find(id)->second.getParameterList();
				vector<string> res;
				for (std::vector<Parameter>::iterator x = param_list.begin(); x != param_list.end(); ++x)
				{
					res.push_back(x->getValue() + ".int.1");
				}
				return res;
			}
		}
	}
	string gen_mips(string id){
		
		for (int i = scope; i >= 0; i--) {
			if(symbols[i].find(id) !=  symbols[i].end()){
				return id + "." +  TYPE2STRING[symbols[i].find(id)->second.getDataType()] + "." + to_string(i);
			}
		}
		return "";
	}
	vector<string> backup(){

		vector<string> back_var;

		backup_symbols = symbols;

		for(int i = 1; i <= scope; i++)
			for(map<string,SymbolTableAux>::iterator it = symbols[i].begin(); it != symbols[i].end(); ++it)
			{
				back_var.push_back(gen_mips(it->first));
			}

		for(int i = scope ; i > 0; i--)
			symbols.pop_back();

		scope = 0;
		for(int i = 0; i < back_var.size(); i++){
			//cout<<"ABHI" << back_var[i]<<endl;
		}
		return back_var;
	}
	void restore(vector<string> back_var){
		symbols = backup_symbols;
		scope = symbols.size() - 1;
	}

};

class MIPSCode
{
private:
	SymbolTable symtab, backup_symtab;	
	stringstream mips_1, mips_2, intermediate_code;
	int label_counter;
	int string_var_counter;
	int temp_counter;
	vector<string> breaks;
	vector<string> continues;
	vector< pair<string, DataType> > allVariables;
	vector< pair<string, string> > stringLiterals;
	string TYPE2STRING[8] = {"none", "int", "char", "string", "float", "bool", "func", "err"};
public:
	MIPSCode(){
		mips_1 << ".text" << endl;
		label_counter = 0;
		temp_counter = 0;
		string_var_counter = 0;

		breaks.clear();
		continues.clear();
		allVariables.clear();
	}
	string getNextLabel(){
		return "label_" + to_string(label_counter++);
	}
	pair<string, DataType> getNextTempVar(){
		return make_pair("temp" + to_string(temp_counter++), dt_int);
	}
	string getStringVar(){
		return "_str" + to_string(string_var_counter++);
	}
	string putLabel(string label, int param_count){
		label = "_" + label + "_." + to_string(param_count);
		mips_1 << label << " : " << endl;
		return label;
	}
	string putLabel(string label){
		mips_1 << label << " : " << endl;
		return label;
	}
	void loadInRegister(string var, string reg, DataType type){

		if(var[0] <= '9' and var[0] >= '0')	
		{
			mips_1 << "li\t$" << reg <<", " << var << endl;

		} else if (var[0] == '\'') {
			mips_1 << "li\t$" << reg <<", " << var << endl;

		} else if (var[0] == '"') {
			string temp = getStringVar();
			stringLiterals.push_back(make_pair(temp, var));
			mips_1 << "la\t$" << reg <<", " << temp << endl;

		} else {					
			var = "_" + var;
			mips_1 << "lw\t$" << reg <<", " << var << endl;
			for (std::vector<pair<string, DataType> >::iterator i = allVariables.begin(); i != allVariables.end(); ++i) {
				if(i->first == var)
					return;
			}
			allVariables.push_back(make_pair(var, type));
		}
	}
	void storeInMemory(string var, DataType type){
		var = "_"+var;
		mips_1 << "sw\t$t0, " << var << endl;
		for (std::vector<pair<string, DataType> >::iterator i = allVariables.begin(); i != allVariables.end(); ++i) {
			if(i->first == var)
				return;
		}
		allVariables.push_back(make_pair(var, type));
	}
	void ReturnFunc(){
		mips_1 << "jr\t$ra"<<endl;
	}
	void Jump(string label){
		mips_1 << "j\t" << label << endl;
	}
	void condition(string reg, string label){
		mips_1 << "bgtz\t$" << reg <<", "<<label<<endl;
	}
	void functionReturnValue(string reg){
		mips_1 << "move\t$v0, $"<< reg << endl;
	}
	void readCode(string reg){
		mips_1 << "li\t$v0, 5" << endl;
		mips_1 << "syscall" << endl;
		mips_1 << "move\t$"<< reg <<", $v0 "<< endl;
	}
	void writeCode(string reg){
		mips_1 << "li\t$v0, 1" << endl;
		mips_1 << "move\t$a0, $"<< reg << endl;
		mips_1 << "syscall" << endl;
	}
	void writeStringCode(string str_var){
		mips_1 << "li\t$v0, 4" << endl;
		mips_1 << "la\t$a0, ($" << str_var << ")" << endl;
		mips_1 << "syscall" << endl;
	}
	void pushReturnCode(){
		mips_1 << "addi\t$sp,$sp,-4" << endl;
		mips_1 << "sw\t$ra,0($sp)" << endl;
	}
	void popReturnCode(){
		mips_1 << "lw\t$ra,0($sp)" << endl;
		mips_1 << "addi\t$sp,$sp,4" << endl;	}
	void pushCode(string loc){
		mips_1 << "addi	$sp,$sp,-4" << endl;
		mips_1 << "lw	$t8, " << loc << endl;
		mips_1 << "sw	$t8,0($sp)" << endl;
	}
	void popCode(string loc){
		mips_1 << "lw	$t8,0($sp)" << endl;
		mips_1 << "sw	$t8, " << loc << endl;
		mips_1 << "addi	$sp,$sp,4" << endl;
	}
	void copy(string src, string dst){
		mips_1 << "lw\t$t8, " << src << endl;
		mips_1 << "sw\t$t8, " << dst << endl;
	}

	void functionCall(string fun){
		mips_1 << "jal\t" << fun << endl;
	}
	void restoreReturn(string ret){
		mips_1 << "sw\t$v0, _" << ret << endl;
	}
	void operate(string op){
		if(op == "&&") {
			mips_1 << "and\t$t0, $t1, $t2" << endl;
		} else if(op == "||") {
			mips_1 << "or\t$t0, $t1, $t2" << endl;

		} else if(op == "+") {
			mips_1 << "add\t$t0, $t1, $t2" << endl;
		} else if(op == "-") {
			mips_1 << "sub\t$t0, $t1, $t2" << endl;

		} else if(op == "*") {
			mips_1 << "mult\t$t1, $t2" << endl;		
			mips_1 << "mflo\t$t0" << endl;			
		} else if(op == "/") {
			mips_1 << "div\t$t1, $t2" << endl;
			mips_1 << "mflo\t$t0" << endl;
		} else if(op == "%") {
			mips_1 << "div\t$t1, $t2" << endl;
			mips_1 << "mfhi\t$t0" << endl;

		} else if(op == ">=") {
			mips_1 << "slt\t$t3, $t1, $t2" << endl;		
			mips_1 << "xori\t$t0, $t3, 1" << endl;		
		} else if(op == "<=") {
			mips_1 << "slt\t$t3, $t2, $t1" << endl;		
			mips_1 << "xori\t$t0, $t3, 1" << endl;		

		} else if(op == ">") {
			mips_1 << "slt\t$t0, $t2, $t1" << endl;		
		} else if(op == "<") {
			mips_1 << "slt\t$t0, $t1, $t2" << endl;

		} else if(op == "==") {
			mips_1 << "slt\t$t3, $t1, $t2" << endl;
			mips_1 << "slt\t$t4, $t2, $t1" << endl;
			mips_1 << "or\t$t5, $t3, $t4" << endl;
			mips_1 << "xori\t$t0, $t5, 1" << endl;
		} else if(op == "!=") {
			mips_1 << "slt\t$t3, $t1, $t2" << endl;
			mips_1 << "slt\t$t4, $t2, $t1" << endl;
			mips_1 << "or\t$t0, $t3, $t4" << endl;
		} else {
			cerr<<"WRONG OPERATOR PASSED!";
		}
	}
	pair<string, DataType> generateCode(Node *tree){
		if(tree == NULL)	return make_pair("", dt_int);

		string node_type = tree->getType();

		DEBUG cerr << node_type << endl;

		if (node_type == "") { return make_pair("", dt_int);}


		if (node_type == "variable_declaration") {
			if(tree->child3 == NULL){
				vector<string> vars = expandVariablesList(tree->child2);
				for(int i=0; i < vars.size(); i++)
				{
					symtab.addVariableInCurrentScope(vars[i], tree->child1->getDataType());
					intermediate_code << TYPE2STRING[tree->child1->getDataType()] << " " << vars[i] <<endl;
				}
			} else {
				
				symtab.addVariableInCurrentScope(tree->child2->getValue(), tree->child1->getDataType());
				pair<string, DataType> exp = generateCode(tree->child3);
				intermediate_code << TYPE2STRING[tree->child1->getDataType()] << " " << tree->child2->getValue() << " = " << exp.first << endl;
				
				loadInRegister(exp.first, "t0", exp.second);
				storeInMemory(symtab.gen_mips(tree->child2->getValue()), tree->child1->getDataType());
			}
			return make_pair("", dt_int);

		} else if ( node_type == "variable") {
			
			return make_pair(symtab.gen_mips(tree->child1->getValue()), tree->child1->getDataType());

		} else if ( node_type == "function_declaration") {

			vector<Parameter> params = expandParameterList(tree->child2);

			string label = putLabel(tree->getValue(), params.size());
			intermediate_code << tree->getValue() << " : " <<endl;

			symtab.addFunction(label, dt_int, params);

			symtab.addScope();
			for(int i=0;i<params.size();i++)
			{
				symtab.addVariableInCurrentScope(params[i].getValue(), params[i].getDataType());
				intermediate_code << "param " << TYPE2STRING[params[i].getDataType()] << " " << params[i].getValue() <<endl;
			}

			pair<string, DataType> a = generateCode(tree->child3);
			symtab.removeScope();

			ReturnFunc();
			intermediate_code << "return" << endl;

			return make_pair("", dt_int);

		} else if ( node_type == "main_function") {
			mips_1 << "main : "<<endl;
			intermediate_code << "main : "<<endl;

			symtab.addScope();
			pair<string, DataType> a = generateCode(tree->child1);
			symtab.removeScope();
			ReturnFunc();
			intermediate_code << "return" << endl;
			return make_pair("", dt_int);

		} else if ( node_type == "statement") {
			if(tree->getValue() == "break"){
				Jump(breaks.back());
				intermediate_code << "break" <<endl;
			} else if (tree->getValue() == "continue") {
				Jump(continues.back());
				intermediate_code << "continue" <<endl;
			} else if(tree->getValue() == "scope"){
				symtab.addScope();
				intermediate_code << "{" <<endl;
				generateCode(tree->child1);
				symtab.removeScope();
				intermediate_code << "}" <<endl;
			} else {
				generateCode(tree->child1);
			}
			return make_pair("", dt_int);

		} else if ( node_type == "condition") {
			string start = getNextLabel();
			string end = getNextLabel();

			pair<string, DataType> a = generateCode(tree->child1);	

			loadInRegister(a.first, "t1", a.second);
			intermediate_code << "if ( " << a.first <<" > 0 ) jump " << start <<endl;
			
			condition("t1", start);
			
			intermediate_code << "jump " << end <<endl;
			Jump(end);
			
			putLabel(start);
			intermediate_code << start << " : "<<endl;
			symtab.addScope();
			pair<string, DataType> b = generateCode(tree->child2);
			symtab.removeScope();
			putLabel(end);
			intermediate_code << end << " : "<<endl;

			if(tree->child3 != NULL)
			{
				symtab.addScope();
				pair<string, DataType> c = generateCode(tree->child3);
				symtab.removeScope();
			}
			return make_pair("", dt_int);

		} else if ( node_type == "for_loop") {
			string start = getNextLabel();		
			string middle = getNextLabel();		
			string cond = getNextLabel();		
			string end = getNextLabel();		

			breaks.push_back(end);		
			continues.push_back(cond); 	

			generateCode(tree->child1);

			putLabel(start);
			intermediate_code << start << " : " <<endl;

			pair<string, DataType> a = generateCode(tree->child2);
			loadInRegister(a.first, "t0", a.second);

			condition("t0", middle);
			intermediate_code << "if ( " << a.first << " > 0 ) jump "<< middle <<endl;

			Jump(end);
			intermediate_code << "jump " << end <<endl;

			putLabel(middle);
			intermediate_code << middle <<" : " <<endl;

			generateCode(tree->child4);

			putLabel(cond);
			intermediate_code << cond <<" : " <<endl;
			generateCode(tree->child3);

			Jump(start);
			intermediate_code << "jump " << start <<endl;
			putLabel(end);
			intermediate_code << end <<" : " <<endl;

			breaks.pop_back();
			continues.pop_back();
			return(make_pair("", dt_int));

		}  else if ( node_type == "while_loop") {
			string start = getNextLabel();	
			string middle = getNextLabel();		
			string end = getNextLabel();		

			breaks.push_back(end);
			continues.push_back(start);

			putLabel(start);
			intermediate_code << start << " : "<<endl;
			pair<string, DataType> a = generateCode(tree->child1);

			loadInRegister(a.first, "t1", a.second);
			condition("t1", middle);
			Jump(end);
			intermediate_code << "if ( " << a.first << " > 0 ) jump " << middle << endl;
			intermediate_code << "jump " << end<<endl;
			putLabel(middle);
			intermediate_code << middle << " : "<<endl;
			symtab.addScope();
			pair<string, DataType> b = generateCode(tree->child2);
			symtab.removeScope();

			Jump(start);
			putLabel(end);

			intermediate_code << "jump " << start <<endl;
			intermediate_code << end << " : "<<endl;

			breaks.pop_back();
			continues.pop_back();

			return make_pair("", dt_int);

		} else if ( node_type == "return_statement") {
			if(tree->child2 == NULL)
			{
				pair<string, DataType> a = generateCode(tree->child2);

				loadInRegister(a.first, "t1", a.second);
				functionReturnValue("t1");
				intermediate_code << "return " << a.first << endl;
			}
			ReturnFunc();

			return make_pair("", dt_int);

		} else if ( node_type == "read") {
			pair<string, DataType> a = generateCode(tree->child1);
			loadInRegister(a.first, "t0", a.second);
			readCode("t0");
			storeInMemory(a.first, a.second);
			intermediate_code << "read " << a.first << endl;
			return a;

		} else if ( node_type == "write") {
			pair<string, DataType> a = generateCode(tree->child1);
			loadInRegister(a.first, "t1", a.second);
			writeCode("t1");
			intermediate_code << "write " << a.first << endl;
			return a;

		} else if ( node_type == "expression") {
			pair<string, DataType> b;
			if(tree->getValue() == "=") {
				pair<string, DataType> a = generateCode(tree->child2);
				b = generateCode(tree->child1);
				loadInRegister(a.first, "t0", a.second);
				storeInMemory(b.first, b.second);
				intermediate_code << b.first << " = " << a.first <<endl;
			} else {
				b = generateCode(tree->child1);
			}
			pair<string, DataType> ret = getNextTempVar();

			loadInRegister(b.first, "t0", b.second);
			storeInMemory(ret.first, b.second);
			intermediate_code << ret.first << " = " << b.first <<endl;

			return ret;

		} else if ( node_type == "logical_expression") {
			if(tree->getValue() == "or") {
				pair<string, DataType> a = generateCode(tree->child2);
				pair<string, DataType> b = generateCode(tree->child1);
				pair<string, DataType> ret = getNextTempVar();

				loadInRegister(b.first, "t1", b.second);
				loadInRegister(a.first, "t2", a.second);
				operate("||");
				storeInMemory(ret.first, dt_bool);

				intermediate_code << ret.first << " = " << a.first << " || " << b.first << endl;

				return ret;

			} else {
				return generateCode(tree->child1);
			}

		} else if ( node_type == "and_expression") {
			if(tree->getValue() == "and") {
				pair<string, DataType> a = generateCode(tree->child2);
				pair<string, DataType> b = generateCode(tree->child1);
				pair<string, DataType> ret = getNextTempVar();

				loadInRegister(b.first, "t1", b.second);
				loadInRegister(a.first, "t2", a.second);
				operate("&&");
				storeInMemory(ret.first, dt_bool);
				intermediate_code << ret.first << " = " << a.first << " && " << b.first << endl;
				return ret;

			} else {
				return generateCode(tree->child1);
			}

		} else if ( node_type == "relational_expression") {
			if(tree->getValue() == "op")
			{
				pair<string, DataType> a = generateCode(tree->child3);
				pair<string, DataType> b = generateCode(tree->child1);
				pair<string, DataType> c = generateCode(tree->child2);
				pair<string, DataType> ret = getNextTempVar();

				loadInRegister(b.first, "t1", b.second);
				loadInRegister(a.first, "t2", a.second);
				operate(c.first);
				storeInMemory(ret.first, dt_bool);
				intermediate_code << ret.first << " = " << a.first << " " << c.first << " " << b.first << endl;
				return ret;
			} else {
				return generateCode(tree->child1);
			}

		} else if ( node_type == "simple_expression") {
			if(tree->child3 != NULL)
			{
				pair<string, DataType> a = generateCode(tree->child3);
				pair<string, DataType> b = generateCode(tree->child1);
				pair<string, DataType> c = generateCode(tree->child2);
				pair<string, DataType> ret = getNextTempVar();

				loadInRegister(b.first, "t1", b.second);
				loadInRegister(a.first, "t2", a.second);
				operate(c.first);
				storeInMemory(ret.first, DatatypeCoercible(a.second, b.second));
				intermediate_code << ret.first << " = " << a.first << " " << c.first << " " << b.first << endl;
				return ret;
			} else {
				return generateCode(tree->child1);
			}

		} else if ( node_type == "divmul_expression") {
			if(tree->child3 != NULL)
			{
				pair<string, DataType> a = generateCode(tree->child3);
				pair<string, DataType> b = generateCode(tree->child1);
				pair<string, DataType> c = generateCode(tree->child2);
				pair<string, DataType> ret = getNextTempVar();

				loadInRegister(b.first, "t1", b.second);
				loadInRegister(a.first, "t2", a.second);
				operate(c.first);
				storeInMemory(ret.first, DatatypeCoercible(a.second, b.second));
				intermediate_code << ret.first << " = " << a.first << " " << c.first << " " << b.first << endl;
				return ret;
			} else {
				return generateCode(tree->child1);
			}

		} else if ( node_type == "unary_expression") {
			if(tree->child3 != NULL){

				pair<string, DataType> a = generateCode(tree->child2);
				pair<string, DataType> b = generateCode(tree->child1);
				pair<string, DataType> ret = getNextTempVar();

				loadInRegister("0", "t1", dt_int);
				loadInRegister(a.first, "t2", a.second);
				operate(b.first);
				storeInMemory(ret.first, DatatypeCoercible(a.second, b.second));
				intermediate_code << ret.first << " = " << a.first << " " << b.first << " 0" << endl;
				return make_pair(ret.first, ret.second);
			} else {
				return generateCode(tree->child1);
			}

		} else if ( node_type == "term") {
			return generateCode(tree->child1);

		} else if ( node_type == "constants") {
			return make_pair(tree->getValue(), tree->getDataType());;

		} else if ( node_type == "function_call") {
			
			intermediate_code << "call " << tree->getValue() <<endl;
			vector<string> args = expandArgumentsList(tree->child1);
			vector<string> pars = symtab.getFunctionParameters("_" + tree->getValue() + "_." + to_string(args.size()));

			pushReturnCode();

			vector<string> backvars = symtab.backup();
			for(int i=0;i<backvars.size();i++)
			{
				pushCode("_"+backvars[i]);
			}

			
			for(int i=0;i < args.size(); i++)
			{
				copy("_"+args[i]+".int.1", "_"+pars[i]);
			}

			
			functionCall("_" + tree->getValue() + "_." + to_string(args.size()));

			for(int i = backvars.size()-1;i>=0;i--)
			{
				popCode("_"+backvars[i]);
			}
			
			symtab.restore(backvars);

			popReturnCode();

			pair<string, DataType> ret = getNextTempVar();

			restoreReturn(ret.first);
			ReturnFunc();

			return ret;
		} else if (node_type == "write_string") {
			loadInRegister(tree->child1->getValue(), "t0", dt_string);
			writeStringCode("t0");
			intermediate_code << "puts " << tree->child1->getValue() <<endl;
			return make_pair("", dt_int);

		} else if ( node_type == "unary_operator" || node_type == "operator3" || node_type == "operator2" || node_type == "operator1") {
			return make_pair(tree->getValue(), tree->getDataType());
		} else {
			generateCode(tree->child1);
			generateCode(tree->child2);
			generateCode(tree->child3);
			return make_pair("", dt_int);
		}
	}

	void generateDataSection(){
		mips_2 << ".data" << endl;
		for(vector<pair< string, string> >::iterator i = stringLiterals.begin(); i != stringLiterals.end(); i++)
		{
			mips_2 << i->first << ":\t\t.asciiz " << i->second << endl;
		}

		for( vector < pair < string , DataType > > :: iterator i = allVariables.begin(); i != allVariables.end(); i++){
			if(i->second == dt_none || i->second == dt_int || i->second == dt_bool){
				mips_2 << i->first << ":\t\t.word 0" << endl;
			} else if(i->second == dt_float){
				mips_2 << i->first << ":\t\t.float 0.0" << endl;
			} else if (i->second == dt_string){
				mips_2 << i->first << ":\t\t.space 20" << endl;
			}
		}
		mips_2 << mips_1.str();
		return;
	}

	void generateOutput(){
		fstream InterFile, MIPSFile;
		MIPSFile.open("mips.s", fstream::out);
		MIPSFile << mips_2.str() ;
		MIPSFile.close();
		return ;
	}

	vector<string> expandVariablesList(Node *tree){
		vector<string> res;
		if(tree->getType() != "variable_list"){
			return res;
		} else if(tree->child2 == NULL){
			res.push_back(tree->child1->getValue());
		} else {
			res.push_back(tree->child2->getValue());
			vector <string> temp = expandVariablesList(tree->child1);
			for (std::vector<string>::reverse_iterator i = temp.rbegin(); i != temp.rend(); ++i){
				res.insert(res.begin(), *i);
			}
		}
		return res;
	}

	vector <Parameter> expandParameterList(Node *tree){
		if(tree->getType() != "parameters" || tree->child1 == NULL){
			return vector<Parameter>();
		} else {
			Node *paramlist = tree->child1;
			return expandParameterListAux(paramlist);
		}
	}

	vector<Parameter> expandParameterListAux(Node *tree){
		vector<Parameter> res;
		if(tree->getType() != "parameters_list"){
			return res;
		}
		if(tree->child2 == NULL){
			res.push_back(Parameter(tree->child1->child2->getValue(), tree->child1->getDataType()));
			return res;
		}
		res = expandParameterListAux(tree->child1);
		res.push_back(Parameter(tree->child2->child2->getValue(), tree->child2->getDataType()));
		return res;
	}

	vector<string> expandArgumentsList(Node *Tree){
		vector<string> v;
		v.clear();
		if(Tree->getType() != "args" || Tree->child1 == NULL) {return v;}
		Node *args_list = Tree->child1;
		return expandArgumentsListAux(args_list);
	}

	vector<string> expandArgumentsListAux(Node *tree){
		vector<string> res;
		res.clear();
		if(tree->getType() != "args_list"){
			return res;
		}
		if(tree->child2 == NULL){
			res.push_back(tree->child1->getValue());
			return res;
		}

		res = expandArgumentsListAux(tree->child1);
		res.push_back(tree->child2->getValue());

		return res;
	}

	DataType DatatypeCoercible(DataType dt1, DataType dt2){
		if (dt1 == dt2) {
			return dt1;
		} else if((dt1 == dt_int || dt1 == dt_float) && ((dt2 == dt_int || dt2 == dt_float))){
			return dt_float;
		} else {
			return dt_int;
		}
	}
};
